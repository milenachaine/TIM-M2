from similarite_with_class import getBestQuestion
bestQuestion = getBestQuestion(msg)