#FLASK_APP=test.py flask run 
# OU 
#python3 test.py
from flask import Flask #importer flask
from flask import render_template 
#Instancier l'objet app : le site Web
app = Flask(__name__) 
app.debug = True #'False' A LA MISE EN LIGNE

@app.route("/")
def index():

	logs=[("pers", "Am Stram"), ("bot", "Gramm"), ("pers", "Pique et Pique"), ("bot", "Et collégramme")]
	return render_template("chatroom.html", discussion = logs)



	
if __name__ == '__main__':
	app.run()#Lance le serveur